import{w as I,d as $,p as T,j as e,X as k}from"./index-D6B8zBTG.js";import{E as M,a as R}from"./jspdf.plugin.autotable-D2oCugZu.js";import{u as q}from"./useDispatches-BeTfRjbJ.js";import{B as y}from"./Button-DNtRpWMD.js";import{C as z}from"./circle-alert-BdSI2NKL.js";import{P as j}from"./printer-SlJY24iL.js";import{D as F}from"./download-Cje-9rbv.js";import{f as w}from"./format-BMMjC7N5.js";const E={PENDIENTE:{label:"PENDIENTE",color:"bg-amber-100 text-amber-800 border border-amber-200",icon:T},EN_PROCESO:{label:"EN PROCESO",color:"bg-blue-100 text-blue-800 border border-blue-200",icon:z},CONFIRMADO:{label:"CONFIRMADO",color:"bg-purple-100 text-purple-800 border border-purple-200",icon:$},DESPACHADO:{label:"DESPACHADO",color:"bg-emerald-100 text-emerald-800 border border-emerald-200",icon:I}},G=({order:t,onClose:S})=>{var g;const{getProduct:m,getWarehouse:A,warehouseSpaces:u,evaluateSpacePreselection:D}=q();if(!t)return null;const f=t.createdAt?w(new Date(t.createdAt),"dd/MM/yyyy HH:mm"):"—",x=((g=A(t.warehouseId))==null?void 0:g.name)??t.warehouseId,p=E[t.status]??E.PENDIENTE,C=p.icon,b=l=>{var i;if(l.productId.startsWith("manual-"))return[{spaceName:"-",qty:l.quantityRequired}];const o=l.warehouseSpaceAssignments??[];if(o.length===0){const a=l.warehouseSpaceId,n=D(l.productId,t.warehouseId,l.quantityRequired);return[{spaceName:a?((i=u.find(r=>String(r.id)===String(a)))==null?void 0:i.name)??`Espacio #${a}`:(n==null?void 0:n.autoPreselectedSpaceName)??"-",qty:l.quantityRequired}]}return o.map(a=>{const n=u.find(d=>String(d.id)===String(a.warehouseSpaceId));return{spaceName:(n==null?void 0:n.name)??`Espacio #${a.warehouseSpaceId}`,qty:a.quantity}})},P=()=>{var l;try{const s=new M;s.setFontSize(16),s.setTextColor(37,99,235),s.text("SUPREPARTS - ORDEN DE DESPACHO",14,18),s.setFontSize(9),s.setTextColor(80),s.text(`Código Orden: ${t.code}`,14,26),s.text(`Fecha: ${w(new Date(t.createdAt),"dd/MM/yyyy")}`,14,31),s.text(`Estado: ${t.status}`,14,36),s.text(`Cliente: ${t.clientName}`,120,26),s.text(`Solicitado por: ${t.requestedBy}`,120,31),s.text(`Almacén: ${x}`,120,36),s.text(`Tipo Entrega: ${t.deliveryType}`,120,41),s.setDrawColor(200),s.line(14,46,196,46);const o=[];t.items.forEach(a=>{const n=a.productId.startsWith("manual-"),d=n?null:m(a.productId),r=n?"MANUAL":(d==null?void 0:d.code)??a.productId,c=n?a.notes??"-":(d==null?void 0:d.name)??"-";b(a).forEach((N,v)=>{o.push([v===0?r:"",v===0?c:"",N.spaceName,String(N.qty)])})}),R(s,{startY:50,head:[["CÓDIGO","PRODUCTO","ESPACIO ALMACÉN","CANT. TOMADA"]],body:o,headStyles:{fillColor:[37,99,235],textColor:255},styles:{fontSize:9,cellPadding:3},columnStyles:{3:{halign:"center"}}});const i=((l=s.lastAutoTable)==null?void 0:l.finalY)??150;t.notes&&(s.setFont("helvetica","normal"),s.setFontSize(8),s.setTextColor(100),s.text("NOTAS / OBSERVACIONES:",14,i+10),s.text(t.notes,14,i+16,{maxWidth:170})),s.save(`Orden_Despacho_${t.code}.pdf`)}catch(s){console.error("Error al generar PDF:",s),alert("Error al generar la descarga del PDF.")}},O=()=>{const l=window.open("","_blank","width=850,height=900");if(!l){alert("Por favor permite las ventanas emergentes para imprimir.");return}const s=t.items.map(o=>{const i=o.productId.startsWith("manual-"),a=i?null:m(o.productId),n=i?"MANUAL":(a==null?void 0:a.code)??o.productId,d=i?o.notes??"-":(a==null?void 0:a.name)??"-";return b(o).map((c,h)=>`
        <tr>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; font-family: monospace; font-weight: bold; color: #1e293b;">${h===0?n:""}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; color: #334155;">${h===0?d:""}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold; color: #059669;">${c.spaceName}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: #1e293b;">${c.qty}</td>
        </tr>
      `).join("")}).join("");l.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Orden de Despacho ${t.code}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 30px; color: #1e293b; line-height: 1.5; }
            .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #2563eb; padding-bottom: 15px; margin-bottom: 20px; }
            .brand { font-size: 22px; font-weight: bold; color: #2563eb; letter-spacing: -0.5px; }
            .doc-title { font-size: 16px; font-weight: bold; margin-top: 4px; color: #0f172a; }
            .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; background: #f8fafc; padding: 15px; border-radius: 12px; margin-bottom: 25px; font-size: 13px; border: 1px solid #e2e8f0; }
            .meta-item { margin-bottom: 6px; }
            .meta-label { color: #64748b; font-size: 11px; font-weight: bold; text-transform: uppercase; }
            .meta-value { font-weight: 600; color: #0f172a; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 13px; }
            th { background: #2563eb; color: white; padding: 10px 12px; text-align: left; font-size: 12px; font-weight: bold; text-transform: uppercase; }
            th.center { text-align: center; }
            .notes { bg-color: #fffbe0; background: #fffbe0; border: 1px solid #fef08a; padding: 12px; border-radius: 8px; font-size: 12px; color: #854d0e; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="brand">SUPREPARTS</div>
              <div class="doc-title">ORDEN DE DESPACHO</div>
            </div>
            <div style="text-align: right; font-size: 13px;">
              <div style="font-family: monospace; font-weight: bold; font-size: 18px; color: #2563eb;">${t.code}</div>
              <div style="color: #64748b; margin-top: 4px;">Fecha: ${f}</div>
              <div style="margin-top: 4px;">Estado: <strong>${t.status}</strong></div>
            </div>
          </div>

          <div class="meta-grid">
            <div>
              <div class="meta-item"><span class="meta-label">Cliente:</span> <span class="meta-value">${t.clientName}</span></div>
              <div class="meta-item"><span class="meta-label">Quien Solicita:</span> <span class="meta-value">${t.requestedBy}</span></div>
            </div>
            <div>
              <div class="meta-item"><span class="meta-label">Almacén:</span> <span class="meta-value">${x}</span></div>
              <div class="meta-item"><span class="meta-label">Tipo de Entrega:</span> <span class="meta-value">${t.deliveryType}</span></div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Código</th>
                <th>Producto</th>
                <th>Espacio Almacén</th>
                <th class="center">Cantidad</th>
              </tr>
            </thead>
            <tbody>
              ${s}
            </tbody>
          </table>

          ${t.notes?`<div class="notes"><strong>Notas / Observaciones:</strong><br/>${t.notes}</div>`:""}

          <script>
            window.onload = function() { window.print(); };
          <\/script>
        </body>
      </html>
    `),l.document.close()};return e.jsx("div",{className:"fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto",children:e.jsxs("div",{className:"bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150",children:[e.jsxs("div",{className:"bg-slate-900 text-white px-6 py-4 flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"bg-blue-600 p-2 rounded-xl text-white",children:e.jsx(j,{className:"w-5 h-5"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"font-bold text-base",children:"Previsualización de Impresión"}),e.jsxs("p",{className:"text-xs text-slate-300",children:["Orden de Despacho ",e.jsx("span",{className:"font-mono text-blue-300 font-bold",children:t.code})]})]})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs(y,{onClick:O,className:"gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg border-0",children:[e.jsx(j,{className:"w-3.5 h-3.5"}),"Imprimir"]}),e.jsxs(y,{onClick:P,className:"gap-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg border-0",children:[e.jsx(F,{className:"w-3.5 h-3.5"}),"Descargar PDF"]}),e.jsx("button",{onClick:S,className:"text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors ml-2",children:e.jsx(k,{className:"w-5 h-5"})})]})]}),e.jsx("div",{className:"p-6 overflow-y-auto max-h-[calc(90vh-80px)] space-y-5 bg-white",children:e.jsxs("div",{className:"border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5 bg-white",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4",children:[e.jsxs("div",{children:[e.jsx("h4",{className:"text-xl font-bold text-blue-600 tracking-tight",children:"SUPREPARTS"}),e.jsx("p",{className:"text-sm font-bold text-slate-700 mt-0.5",children:"ORDEN DE DESPACHO"})]}),e.jsxs("div",{className:"text-left sm:text-right",children:[e.jsx("span",{className:"font-mono text-xl font-extrabold text-blue-700 bg-blue-50 px-3 py-1 rounded-lg border border-blue-200 inline-block",children:t.code}),e.jsxs("p",{className:"text-xs text-slate-500 mt-1 font-medium",children:["Fecha: ",f]}),e.jsx("div",{className:"mt-1",children:e.jsxs("span",{className:`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${p.color}`,children:[e.jsx(C,{className:"w-3 h-3"}),p.label]})})]})]}),e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs",children:[e.jsxs("div",{children:[e.jsx("span",{className:"block text-[10px] font-bold text-slate-400 uppercase",children:"Cliente"}),e.jsx("span",{className:"font-semibold text-slate-800",children:t.clientName})]}),e.jsxs("div",{children:[e.jsx("span",{className:"block text-[10px] font-bold text-slate-400 uppercase",children:"Quien Solicita"}),e.jsx("span",{className:"font-semibold text-slate-800",children:t.requestedBy})]}),e.jsxs("div",{children:[e.jsx("span",{className:"block text-[10px] font-bold text-slate-400 uppercase",children:"Almacén"}),e.jsx("span",{className:"font-semibold text-slate-800",children:x})]}),e.jsxs("div",{children:[e.jsx("span",{className:"block text-[10px] font-bold text-slate-400 uppercase",children:"Tipo Entrega"}),e.jsx("span",{className:"font-semibold text-slate-800",children:t.deliveryType})]})]}),e.jsx("div",{className:"border border-slate-200 rounded-xl overflow-hidden",children:e.jsxs("table",{className:"w-full text-xs text-left",children:[e.jsx("thead",{className:"bg-blue-600 text-white font-bold uppercase text-[11px]",children:e.jsxs("tr",{children:[e.jsx("th",{className:"px-4 py-2.5",children:"Código"}),e.jsx("th",{className:"px-4 py-2.5",children:"Producto"}),e.jsx("th",{className:"px-4 py-2.5",children:"Espacio Almacén"}),e.jsx("th",{className:"px-4 py-2.5 text-center",children:"Cant. Tomada"})]})}),e.jsx("tbody",{className:"divide-y divide-slate-100",children:t.items.flatMap(l=>{const s=l.productId.startsWith("manual-"),o=s?null:m(l.productId),i=s?"MANUAL":(o==null?void 0:o.code)??l.productId,a=s?l.notes??"-":(o==null?void 0:o.name)??"-";return b(l).map((d,r)=>e.jsxs("tr",{className:"hover:bg-slate-50",children:[e.jsx("td",{className:"px-4 py-2.5 font-mono font-bold text-slate-700",children:r===0?i:""}),e.jsx("td",{className:"px-4 py-2.5 font-medium text-slate-800",children:r===0?a:""}),e.jsx("td",{className:"px-4 py-2.5 font-bold text-emerald-700",children:d.spaceName}),e.jsx("td",{className:"px-4 py-2.5 text-center font-bold text-slate-900 text-sm",children:d.qty})]},`${l.id}-${r}`))})})]})}),t.notes&&e.jsxs("div",{className:"bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900",children:[e.jsx("strong",{className:"block text-amber-800 font-bold mb-0.5",children:"Notas / Observaciones:"}),e.jsx("p",{children:t.notes})]})]})})]})})};export{G as D};
