import{r,j as e}from"./index-D6B8zBTG.js";import{u as T}from"./usePurchasing-BA-XCHO-.js";import{B as p}from"./Button-DNtRpWMD.js";import{I as f}from"./Input-C5Fc6WBm.js";import{B as I}from"./Badge-k1NAMf-1.js";import{Q as O}from"./QRScannerModal-eeZbjLRw.js";import A from"./html2canvas.esm-QH1iLAAe.js";import{T as L}from"./tag-DML3p-Lu.js";import{S as J}from"./search-CEucY7pQ.js";import{S as _}from"./scan-DFPJvbmV.js";import{S as F}from"./sliders-vertical-COXFh-5h.js";import{D as M}from"./download-Cje-9rbv.js";import{P as Q}from"./printer-SlJY24iL.js";import"./qr-code-HIL_tuVt.js";const le=()=>{const{products:m,getCategory:h}=T(),[i,b]=r.useState(""),[s,z]=r.useState(()=>m[0]||null),[u,D]=r.useState("30"),[g,j]=r.useState(""),[w,v]=r.useState(""),[R,N]=r.useState(!1),[y,S]=r.useState(!1),n=r.useRef(null),k=t=>{z(t);const o=h(t.categoryId);j((o==null?void 0:o.code)||"-"),v(t.name),b("")},q=(t,o)=>{const l=t.trim().toLowerCase(),d=m.find(x=>x.code.toLowerCase()===l||x.id.toLowerCase()===l||x.name.toLowerCase().includes(l));d?k(d):alert(`No se encontró producto con código: "${t}"`)},a=s?h(s.categoryId):null,c=w||(s==null?void 0:s.name)||"NOMBRE DEL PRODUCTO",C=g||(a==null?void 0:a.code)||"B",P=u||"0",B=async()=>{if(n.current){S(!0);try{const o=(await A(n.current,{scale:4,backgroundColor:"#ffffff",useCORS:!0,logging:!1})).toDataURL("image/jpeg",.98),l=document.createElement("a"),d=s?`etiqueta_${s.code}_60x40.jpg`:"etiqueta_identificadora_60x40.jpg";l.download=d,l.href=o,l.click()}catch(t){console.error("Error al generar JPG:",t),alert("Error al generar la imagen JPG de la etiqueta.")}finally{S(!1)}}},G=()=>{if(!n.current)return;const t=window.open("","_blank","width=600,height=500");if(!t){alert("Por favor permita las ventanas emergentes para imprimir la etiqueta.");return}n.current.outerHTML,t.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Imprimir Etiqueta Identificadora (60x40mm)</title>
          <style>
            @page {
              size: 60mm 40mm;
              margin: 0;
            }
            * {
              box-sizing: border-box;
              margin: 0;
              padding: 0;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            html, body {
              width: 60mm;
              height: 40mm;
              margin: 0;
              padding: 0;
              background: #fff;
              display: flex;
              align-items: center;
              justify-content: center;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            }
            .label-container {
              width: 58mm;
              height: 38mm;
              border: 2.5px solid #000;
              display: flex;
              flex-direction: column;
              background: #fff;
            }
            .top-box {
              flex: 1.6;
              border-bottom: 2.5px solid #000;
              display: flex;
              align-items: center;
              justify-content: center;
              text-align: center;
              padding: 3px 6px;
              font-weight: 900;
              font-size: 14pt;
              line-height: 1.15;
              text-transform: uppercase;
              word-break: break-word;
            }
            .bottom-row {
              flex: 1;
              display: flex;
              width: 100%;
            }
            .bottom-left {
              flex: 1;
              border-right: 2.5px solid #000;
              display: flex;
              align-items: center;
              justify-content: center;
              font-weight: 900;
              font-size: 20pt;
              text-transform: uppercase;
            }
            .bottom-right {
              flex: 1;
              display: flex;
              align-items: center;
              justify-content: center;
              font-weight: 900;
              font-size: 20pt;
            }
          </style>
        </head>
        <body>
          <div class="label-container">
            <div class="top-box">${c}</div>
            <div class="bottom-row">
              <div class="bottom-left">${C}</div>
              <div class="bottom-right">${P}</div>
            </div>
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(() => { window.close(); }, 500);
            };
          <\/script>
        </body>
      </html>
    `),t.document.close()},E=i?m.filter(t=>t.name.toLowerCase().includes(i.toLowerCase())||t.code.toLowerCase().includes(i.toLowerCase())).slice(0,5):[];return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-200/80 rounded-2xl p-4 flex items-center justify-between gap-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"p-2.5 bg-amber-500 text-white rounded-xl shadow-sm",children:e.jsx(L,{className:"w-5 h-5"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-base font-bold text-slate-900",children:"Etiqueta Identificadora de Producto (60mm x 40mm)"}),e.jsx("p",{className:"text-xs text-slate-600",children:"Genera e imprime etiquetas térmicas estándar con el nombre del producto, código de categoría y cantidad libre."})]})]}),e.jsx(I,{variant:"outline",className:"hidden sm:inline-flex bg-white text-amber-700 border-amber-300 font-mono text-xs",children:"Formato: 60 x 40 mm (JPG / Térmico)"})]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-6",children:[e.jsxs("div",{className:"lg:col-span-5 space-y-6",children:[e.jsxs("div",{className:"bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("h3",{className:"font-semibold text-slate-900 text-sm flex items-center gap-2",children:[e.jsx(J,{className:"w-4 h-4 text-amber-600"}),"1. Seleccionar Producto Registrado"]}),e.jsxs(p,{type:"button",variant:"outline",size:"sm",onClick:()=>N(!0),className:"text-xs text-amber-700 border-amber-200 hover:bg-amber-50",children:[e.jsx(_,{className:"w-3.5 h-3.5 mr-1"}),"Escanear"]})]}),e.jsxs("div",{className:"relative",children:[e.jsx(f,{placeholder:"Buscar por código o nombre de producto...",value:i,onChange:t=>b(t.target.value),className:"w-full text-sm"}),i&&E.length>0&&e.jsx("div",{className:"absolute z-20 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-56 overflow-y-auto divide-y divide-slate-100",children:E.map(t=>e.jsxs("button",{onClick:()=>k(t),className:"w-full text-left px-3.5 py-2.5 hover:bg-amber-50/60 transition-colors flex items-center justify-between group",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-semibold text-slate-900 group-hover:text-amber-700",children:t.name}),e.jsx("p",{className:"text-[11px] text-slate-500 font-mono",children:t.code})]}),e.jsx(L,{className:"w-3.5 h-3.5 text-slate-300 group-hover:text-amber-600"})]},t.id))})]}),s?e.jsxs("div",{className:"bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-1",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("span",{className:"text-[10px] uppercase font-bold text-slate-400",children:"Producto Actual"}),e.jsx(I,{variant:"outline",className:"text-[10px] font-mono bg-white",children:s.code})]}),e.jsx("p",{className:"text-sm font-bold text-slate-800",children:s.name}),e.jsxs("p",{className:"text-xs text-slate-500",children:["Categoría Sistema: ",e.jsxs("strong",{className:"text-slate-700",children:[(a==null?void 0:a.name)||"-"," (",(a==null?void 0:a.code)||"-",")"]})]})]}):e.jsx("p",{className:"text-xs text-slate-400 italic",children:"No hay producto seleccionado. Selecciona uno del listado."})]}),e.jsxs("div",{className:"bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4",children:[e.jsxs("h3",{className:"font-semibold text-slate-900 text-sm flex items-center gap-2",children:[e.jsx(F,{className:"w-4 h-4 text-amber-600"}),"2. Parámetros de la Etiqueta"]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-xs font-medium text-slate-700 mb-1",children:"Nombre del Producto (Caja Superior)"}),e.jsx("textarea",{value:w,onChange:t=>v(t.target.value),placeholder:"Nombre para la etiqueta...",rows:2,className:"w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold uppercase text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/40"}),e.jsx("span",{className:"text-[10px] text-slate-400",children:"Se ajusta automáticamente en mayúsculas centradas."})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-3",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-xs font-medium text-slate-700 mb-1",children:"Cat. (Lado Izq.)"}),e.jsx(f,{value:g,onChange:t=>j(t.target.value),placeholder:"Ej: B, A...",className:"text-center font-bold text-sm uppercase bg-slate-50 focus:bg-white"})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-xs font-medium text-slate-700 mb-1",children:["Cantidad (Lado Der.) ",e.jsx("span",{className:"text-amber-600",children:"*"})]}),e.jsx(f,{type:"number",min:"1",value:u,onChange:t=>D(t.target.value),placeholder:"30",className:"text-center font-bold text-sm bg-slate-50 focus:bg-white"})]})]}),e.jsxs("div",{className:"pt-2 flex flex-col sm:flex-row gap-2.5",children:[e.jsxs(p,{onClick:B,disabled:y,className:"flex-1 bg-amber-600 hover:bg-amber-700 text-white text-xs py-2.5 shadow-sm",children:[e.jsx(M,{className:"w-4 h-4 mr-1.5"}),y?"Generando JPG...":"Descargar JPG (60x40mm)"]}),e.jsxs(p,{onClick:G,variant:"outline",className:"flex-1 border-slate-300 text-slate-700 hover:bg-slate-100 text-xs py-2.5",children:[e.jsx(Q,{className:"w-4 h-4 mr-1.5"}),"Imprimir Térmica"]})]})]})]}),e.jsx("div",{className:"lg:col-span-7 space-y-4",children:e.jsxs("div",{className:"bg-white border border-slate-200 rounded-3xl p-6 shadow-sm min-h-[480px] flex flex-col items-center justify-center relative overflow-hidden",children:[e.jsxs("div",{className:"absolute top-4 left-6 flex items-center gap-2",children:[e.jsx("span",{className:"w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"}),e.jsx("span",{className:"text-xs font-semibold text-slate-500 uppercase tracking-wider",children:"Vista Previa 60mm x 40mm (Proporción 3:2)"})]}),e.jsx("div",{className:"my-8 flex items-center justify-center p-4 bg-slate-100/70 rounded-2xl border border-dashed border-slate-300 shadow-inner",children:e.jsxs("div",{ref:n,id:"identifier-label-badge",className:"bg-white text-black border-[3px] border-black flex flex-col select-none shadow-2xl transition-all",style:{width:"360px",height:"240px",boxSizing:"border-box"},children:[e.jsx("div",{className:"flex-1 flex items-center justify-center text-center p-3 border-b-[3px] border-black bg-white",style:{minHeight:"140px"},children:e.jsx("p",{className:"font-black text-black leading-tight tracking-tight uppercase",style:{fontSize:c.length>30?"16px":c.length>20?"18px":"22px",wordBreak:"break-word",fontFamily:"Arial, -apple-system, sans-serif"},children:c})}),e.jsxs("div",{className:"h-[90px] flex divide-x-[3px] divide-black bg-white",children:[e.jsx("div",{className:"flex-1 flex items-center justify-center",children:e.jsx("span",{className:"font-black text-black uppercase",style:{fontSize:"32px",fontFamily:"Arial, -apple-system, sans-serif"},children:C})}),e.jsx("div",{className:"flex-1 flex items-center justify-center",children:e.jsx("span",{className:"font-black text-black font-mono",style:{fontSize:"34px",fontFamily:"Arial, -apple-system, sans-serif"},children:P})})]})]})}),e.jsxs("div",{className:"flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500 bg-slate-50 px-4 py-2 rounded-xl border border-slate-200",children:[e.jsxs("span",{children:["📏 ",e.jsx("strong",{children:"Medidas:"})," 60mm × 40mm"]}),e.jsxs("span",{children:["🖨️ ",e.jsx("strong",{children:"Resolución:"})," 300 DPI (708×472 px)"]}),e.jsxs("span",{children:["🏷️ ",e.jsx("strong",{children:"Compatible:"})," Zebra, Xprinter, Niimbot, Dymo"]})]})]})})]}),e.jsx(O,{isOpen:R,onClose:()=>N(!1),onScan:q,title:"Escanear para Seleccionar Producto"})]})};export{le as ProductIdentifierLabel,le as default};
